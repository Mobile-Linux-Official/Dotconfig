# Data menu makanan
menu_makanan = {
    "nasi pecel": 5000,
}

# Data menu minuman
menu_minuman = {
    "es teh": 2000,
}
