===== Bon Pembayaran =====

Menu Pembelian:
tahu peyet: 2 x Rp 5000 = Rp 10000
Jus Jeruk: 2 x Rp 8000 = Rp 16000

Total Pembayaran: Rp 26000