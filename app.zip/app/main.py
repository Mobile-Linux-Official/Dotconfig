import tkinter as tk
from tkinter import filedialog, messagebox
import os
from database import menu_makanan, menu_minuman

class KasirMakanan:
    def __init__(self, master):
        self.master = master
        master.title("Kasir Makanan")

        # Membuat frame untuk menampung tombol Close App
        self.header_frame = tk.Frame(master)
        self.header_frame.pack(anchor="w")

        # Membuat tombol untuk menutup aplikasi
        self.close_button = tk.Button(self.header_frame, text="Close App", command=master.quit)
        self.close_button.pack(side="left", padx=10, pady=10)

        # Membuat tombol untuk menambahkan menu baru
        self.tambah_menu_button = tk.Button(master, text="Tambah Menu", command=self.tambah_menu)
        self.tambah_menu_button.pack(pady=10)

        # Membuat frame utama untuk menampung frame menu makanan dan minuman
        self.main_frame = tk.Frame(master)
        self.main_frame.pack(pady=20)

        # Membuat frame untuk inputan jumlah menu makanan yang dipesan
        self.input_frame_makanan = tk.LabelFrame(self.main_frame, text="======= Menu Makanan =======")
        self.input_frame_makanan.grid(row=0, column=0, padx=20)

        # Membuat entry dan label untuk setiap menu makanan
        self.menu_entries_makanan = {}
        self.populate_menu(self.input_frame_makanan, menu_makanan, self.menu_entries_makanan)

        # Membuat frame untuk inputan jumlah menu minuman yang dipesan
        self.input_frame_minuman = tk.LabelFrame(self.main_frame, text="====== Menu Minuman ======")
        self.input_frame_minuman.grid(row=0, column=1, padx=20)

        # Membuat entry dan label untuk setiap menu minuman
        self.menu_entries_minuman = {}
        self.populate_menu(self.input_frame_minuman, menu_minuman, self.menu_entries_minuman)

        # Membuat tombol untuk menghitung total pembayaran
        self.total_button = tk.Button(master, text="Hitung Total Pembayaran", command=self.hitung_total)
        self.total_button.pack(pady=10)

        # Membuat frame untuk menampilkan total pembayaran dan tombol cetak bon
        self.total_frame = tk.LabelFrame(master, text="===Total Pembayaran===")
        self.total_frame.pack(pady=20)

        # Entry untuk uang yang dibayar
        self.label_uang_bayar = tk.Label(self.total_frame, text="Uang yang Dibayar:")
        self.label_uang_bayar.pack(padx=5, pady=5)
        self.entry_uang_bayar = tk.Entry(self.total_frame, width=20)
        self.entry_uang_bayar.pack(padx=5, pady=5)

        self.total_value = tk.Label(self.total_frame, text="Total: Rp 0")
        self.total_value.pack(padx=5, pady=5)

        self.kembalian_value = tk.Label(self.total_frame, text="Kembalian: Rp 0")
        self.kembalian_value.pack(padx=5, pady=5)

        self.cetak_bon_button = tk.Button(self.total_frame, text="Cetak Bon", command=self.cetak_bon)
        self.cetak_bon_button.pack(padx=5, pady=5)

    def populate_menu(self, frame, menu, entries):
        for i, (name, price) in enumerate(menu.items()):
            label = tk.Label(frame, text=f"{name} (Rp {price})", anchor="center")
            label.grid(row=i, column=0, padx=5, pady=5, sticky="ew")
            entry = tk.Entry(frame, width=10)
            entry.grid(row=i, column=1, padx=5, pady=5)
            entries[name] = entry

    def tambah_menu(self):
        def add_menu_item():
            name = entry_name.get()
            price = entry_price.get()
            category = var_category.get()
            if name and price.isdigit() and category:
                price = int(price)
                if category == "Makanan":
                    menu_makanan[name] = price
                    self.add_new_menu_item(self.input_frame_makanan, name, price, self.menu_entries_makanan)
                else:
                    menu_minuman[name] = price
                    self.add_new_menu_item(self.input_frame_minuman, name, price, self.menu_entries_minuman)
                self.update_database()
                add_menu_window.destroy()
            else:
                messagebox.showerror("Error", "Nama, harga, dan kategori harus diisi dengan benar.")

        add_menu_window = tk.Toplevel(self.master)
        add_menu_window.title("Tambah Menu Baru")

        tk.Label(add_menu_window, text="Nama Menu:").grid(row=0, column=0, padx=10, pady=10)
        entry_name = tk.Entry(add_menu_window)
        entry_name.grid(row=0, column=1, padx=10, pady=10)

        tk.Label(add_menu_window, text="Harga Menu:").grid(row=1, column=0, padx=10, pady=10)
        entry_price = tk.Entry(add_menu_window)
        entry_price.grid(row=1, column=1, padx=10, pady=10)

        tk.Label(add_menu_window, text="Kategori:").grid(row=2, column=0, padx=10, pady=10)
        var_category = tk.StringVar(value="Makanan")
        tk.Radiobutton(add_menu_window, text="Makanan", variable=var_category, value="Makanan").grid(row=2, column=1, sticky="w")
        tk.Radiobutton(add_menu_window, text="Minuman", variable=var_category, value="Minuman").grid(row=2, column=1, sticky="e")

        tk.Button(add_menu_window, text="Tambah", command=add_menu_item).grid(row=3, column=0, columnspan=2, pady=10)

    def add_new_menu_item(self, frame, name, price, entries):
        row = len(entries)
        label = tk.Label(frame, text=f"{name} (Rp {price})", anchor="center")
        label.grid(row=row, column=0, padx=5, pady=5, sticky="ew")
        entry = tk.Entry(frame, width=10)
        entry.grid(row=row, column=1, padx=5, pady=5)
        entries[name] = entry

    def hitung_total(self):
        total_harga = 0
        try:
            for name, entry in self.menu_entries_makanan.items():
                if entry.get():
                    jumlah = int(entry.get())
                    if jumlah < 0:
                        raise ValueError("Jumlah tidak boleh negatif")
                    total_harga += jumlah * menu_makanan[name]
            for name, entry in self.menu_entries_minuman.items():
                if entry.get():
                    jumlah = int(entry.get())
                    if jumlah < 0:
                        raise ValueError("Jumlah tidak boleh negatif")
                    total_harga += jumlah * menu_minuman[name]
            self.total_value.config(text=f"Total: Rp {total_harga}")

            # Menghitung kembalian
            uang_bayar = self.entry_uang_bayar.get()
            if uang_bayar.isdigit():
                uang_bayar = int(uang_bayar)
                kembalian = uang_bayar - total_harga
                self.kembalian_value.config(text=f"Kembalian: Rp {kembalian}")
            else:
                self.kembalian_value.config(text="Kembalian: Rp 0")

        except ValueError:
            messagebox.showerror("Error", "Masukkan jumlah yang valid untuk setiap menu")

    def cetak_bon(self):
        bon = "===== Bon Pembayaran =====\n\n"
        bon += "Menu Pembelian:\n"
        for name, entry in self.menu_entries_makanan.items():
            if entry.get():
                jumlah = int(entry.get())
                bon += f"{name}: {jumlah} x Rp {menu_makanan[name]} = Rp {jumlah * menu_makanan[name]}\n"
        for name, entry in self.menu_entries_minuman.items():
            if entry.get():
                jumlah = int(entry.get())
                bon += f"{name}: {jumlah} x Rp {menu_minuman[name]} = Rp {jumlah * menu_minuman[name]}\n"
        bon += f"\nTotal Pembayaran: {self.total_value.cget('text')}\n"
        bon += f"Uang yang Dibayar: Rp {self.entry_uang_bayar.get()}\n"
        bon += f"Kembalian: {self.kembalian_value.cget('text')}"

        # Menyimpan bon pembayaran dalam file txt
        filename = filedialog.asksaveasfilename(defaultextension=".txt")
        if filename:
            with open(filename, "w") as f:
                f.write(bon)
            messagebox.showinfo("Info", "Bon pembayaran berhasil disimpan!")
        else:
            messagebox.showwarning("Warning", "Menyimpan bon dibatalkan.")

    def update_database(self):
        with open('database.py', 'w') as db_file:
            db_file.write("# Data menu makanan\n")
            db_file.write("menu_makanan = {\n")
            for name, price in menu_makanan.items():
                db_file.write(f'    "{name}": {price},\n')
            db_file.write("}\n\n")
            db_file.write("# Data menu minuman\n")
            db_file.write("menu_minuman = {\n")
            for name, price in menu_minuman.items():
                db_file.write(f'    "{name}": {price},\n')
            db_file.write("}\n")

if __name__ == "__main__":
    root = tk.Tk()
    my_gui = KasirMakanan(root)
    root.mainloop()
